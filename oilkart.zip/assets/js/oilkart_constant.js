function processConstants() {
    var CONSTANT_OILKART_WEBADDR = "www.oilkart.store";
    var CONSTANT_OILKART_NAME_CAPS = "OILKART";
    var CONSTANT_OILKART_NAME_CAMEL = "Oilkart";
    var CONSTANT_OILKART_NAME_SMALL = "oilkart";
    
    var CONSTANT_OILKART_PHONE = "+91 73737 87673";
    var CONSTANT_OILKART_EMAIL = "oilkart.store@gmail.com";
    var CONSTANT_OILKART_ADDRESS =  'Coimbatore <br>'+
                                    'Tamilnadu<br>'+
                                    'Contact : 737378673<br>'+
                                    'Email : oilkart.store@gmail.com<br>';
    
    $(".constant_oilkart_name_caps").text(CONSTANT_OILKART_NAME_CAPS);
    $(".constant_oilkart_name_camel").text(CONSTANT_OILKART_NAME_CAMEL);
    $(".constant_oilkart_name_small").text(CONSTANT_OILKART_NAME_SMALL);
    $(".constant_oilkart_phone").text(CONSTANT_OILKART_PHONE);
    $(".constant_oilkart_email").text(CONSTANT_OILKART_EMAIL);
    $(".constant_oilkart_address").html(CONSTANT_OILKART_ADDRESS);
    $(".constant_oilkart_webaddr").html(CONSTANT_OILKART_WEBADDR);
}
processConstants();