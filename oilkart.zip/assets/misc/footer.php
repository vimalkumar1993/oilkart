<div class="footer">
  <div class="row" style="padding: 2% 15% 0% 15%;">
    <div class="col-md-3">
<!--      <h5 style="color:#feb81c"><span class="constant_oilkart_name_camel"></span> Store</h5>-->
      <img src="assets/imgs/logo-white.png" width="150"/><br/><br/>
      <span style="font-size:12px;color:white">Online Oil Store from Manufacturer</span>
      <br/><br/>
      <span style="color:#feb81c">Download Mobile App at</span>
      <br/>
      <div class="row" style="margin-top:5px">
        <div class="col-md-6">
            <a href="https://play.google.com/store/apps/details?id=com.cloudvalley.oilkart"><img src="assets/imgs/google_play.png" width="100"/></a>
        </div>
        <div class="col-md-6">
            <!--<img src="assets/img/appleStore.png" width="100"/>-->
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <h5 style="padding-left: 12%;color:#feb81c;">
        Quik Links
      </h5>
      <ul class="ullist">
<!--        <li><a>About Us</a></li>-->
<!--        <li><a>Privacy Policy</a></li>-->
        <li><a onclick="window.location.href = 'help.php'">Help & Support</a></li>
        <li><a>Terms & Conditions</a></li>
<!--        <li><a>Contact Us</a></li>-->
      </ul>
    </div>
    <div class="col-md-3">
      <h5 style="padding-left: 12%;color:#feb81c;">
      Social Media Links
    </h5>
      <ul class="ullist">
        <li><a>Facebook</a></li>
        <li><a>Twitter</a></li>
        <li><a>Instagram</a></li>
        <li><a>LinkedIn</a></li>
        <li><a>Youtube</a></li>
      </ul>
    </div>
    <div class="col-md-3">
      <h5 style="padding-left: 12%;color:#feb81c;">
      Contact Us
    </h5>
    <p style="color:white;padding-left:12%;padding-top: 3%;">
      <b><span class="constant_oilkart_name_camel"></span> Store Pvt. Ltd.,</b><br>
      <span class="constant_oilkart_address"></span>
    </p>
    </div>
  </div>
  <div class="row" style="padding:2% 15% 0% 15%">
    <div class="col-md-6">
      <h5 style="font-size: 1rem;"><span style="color:white">All rights reserved. Copyright 2019.</span><span style="color:#feb81c" class="constant_oilkart_webaddr"></span></h5>
    </div>
    <div class="col-md-6">

    </div>
  </div>
</div>
<script src="assets/js/oilkart_constant.js"></script>