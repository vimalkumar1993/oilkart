<div id="featureProducts" class="productcarousel slide" data-ride="carousel" data-interval="0">
			<!-- Carousel indicators -->
			<!-- <ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target="#myCarousel" data-slide-to="2"></li>
			</ol> -->
			<!-- Wrapper for carousel items -->
			<div class="carousel-inner" id="featureProductPanel">
				<div class="item carousel-item active">
					<div class="row">
						<div class="col-sm-2">
							
						</div>
						
					</div>
				</div>
				
			</div>
			<!-- Carousel controls -->
			<a class="carousel-control left carousel-control-prev" onclick="productSlideLeft('featureProducts');" data-slide="prev">
				<i class="fa fa-angle-left"></i>
			</a>
			<a class="carousel-control right carousel-control-next" onclick="productSlideRight('featureProducts');" data-slide="next">
				<i class="fa fa-angle-right"></i>
			</a>
		</div>
